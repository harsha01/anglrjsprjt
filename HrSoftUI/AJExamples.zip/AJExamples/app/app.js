﻿(function () {
    var id = 'ajExpApp';


    angular.module(id, ['ngRoute']);
}
)();