﻿(function () {

    var id = 'shell';

    angular.module('ajExpApp')
           .controller(id, [shell]);


    function shell() {

    }

})()